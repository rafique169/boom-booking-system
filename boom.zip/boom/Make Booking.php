<?php require_once('Connections/booking.php'); ?>
<?php require_once('Connections/registration.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO registration (Name, Address, EmailAdd, ContactNo, Username, Password) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Name'], "text"),
                       GetSQLValueString($_POST['Address'], "text"),
                       GetSQLValueString($_POST['EmailAdd'], "text"),
                       GetSQLValueString($_POST['ContactNo'], "int"),
                       GetSQLValueString($_POST['Username'], "text"),
                       GetSQLValueString($_POST['Password'], "text"));

  mysql_select_db($database_registration, $registration);
  $Result1 = mysql_query($insertSQL, $registration) or die(mysql_error());

  $insertGoTo = "Make Booking2.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_booking, $booking);
$query_booking = "SELECT * FROM booking";
$booking = mysql_query($query_booking, $booking) or die(mysql_error());
$row_booking = mysql_fetch_assoc($booking);
$totalRows_booking = mysql_num_rows($booking);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Make Booking</title>
<style type="text/css">
<!--
body {
	background-image: url(image/vector-background-23.jpg);
	background-color: #769EE4;
}
#Layer1 {
	position:absolute;
	left:250px;
	top:48px;
	width:422px;
	height:64px;
	z-index:1;
	background-color: #ABBFF1;
}
#Layer2 {
	position:absolute;
	left:289px;
	top:150px;
	width:135px;
	height:30px;
	z-index:2;
	background-color: #550A89;
}
#Layer3 {
	position:absolute;
	left:588px;
	top:150px;
	width:135px;
	height:30px;
	z-index:3;
	background-color: #550A89;
}
#Layer4 {
	position:absolute;
	left:522px;
	top:150px;
	width:135px;
	height:30px;
	z-index:4;
	background-color: #550A89;
}
#Layer5 {
	position:absolute;
	left:738px;
	top:150px;
	width:135px;
	height:30px;
	z-index:5;
	background-color: #550A89;
}
#Layer6 {
	position:absolute;
	left:887px;
	top:150px;
	width:135px;
	height:30px;
	z-index:6;
	background-color: #550A89;
}
#Layer7 {
	position:absolute;
	left:440px;
	top:150px;
	width:135px;
	height:30px;
	z-index:7;
	background-color: #550A89;
}
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 18px;
}
#Layer8 {
	position:absolute;
	left:769px;
	top:107px;
	width:331px;
	height:20px;
	z-index:8;
	background-color: #550A89;
}
#Layer9 {
	position:absolute;
	left:208px;
	top:220px;
	width:503px;
	height:278px;
	z-index:9;
	background-color: #000000;
}
#Layer10 {
	position:absolute;
	left:752px;
	top:221px;
	width:331px;
	height:30px;
	z-index:10;
	background-color: #550A89;
}
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 18px; color: #FFFFFF; }
#Layer11 {
	position:absolute;
	left:752px;
	top:251px;
	width:330px;
	height:295px;
	z-index:11;
}
#Layer12 {
	position:absolute;
	left:208px;
	top:553px;
	width:491px;
	height:236px;
	z-index:12;
	background-color: #000000;
}
#Layer13 {
	position:absolute;
	left:283px;
	top:678px;
	width:193px;
	height:48px;
	z-index:13;
	background-color: #000000;
}
#Layer14 {
	position:absolute;
	left:283px;
	top:594px;
	width:186px;
	height:63px;
	z-index:14;
	background-color: #000000;
}
#Layer15 {
	position:absolute;
	left:739px;
	top:570px;
	width:348px;
	height:244px;
	z-index:15;
	background-color: #000000;
}
#Layer16 {
	position:absolute;
	left:223px;
	top:885px;
	width:878px;
	height:63px;
	z-index:16;
	background-color: #460971;
}
#Layer17 {
	position:absolute;
	left:234px;
	top:894px;
	width:197px;
	height:44px;
	z-index:17;
}
#Layer18 {
	position:absolute;
	left:443px;
	top:894px;
	width:182px;
	height:44px;
	z-index:18;
}
#Layer19 {
	position:absolute;
	left:839px;
	top:900px;
	width:236px;
	height:35px;
	z-index:19;
}
.style11 {color: #FFFFFF}
#Layer20 {
	position:absolute;
	left:833px;
	top:28px;
	width:265px;
	height:58px;
	z-index:20;
	background-color: #000000;
}
.style13 {
	font-size: 24px;
	color: #565A5C;
}
#Layer21 {
	position:absolute;
	left:299px;
	top:271px;
	width:695px;
	height:494px;
	z-index:21;
	background-color: #000000;
}
#Layer22 {
	position:absolute;
	left:230px;
	top:211px;
	width:128px;
	height:31px;
	z-index:22;
	background-color: #550A89;
}
.style15 {
	font-size: 16px;
	font-family: Arial, Helvetica, sans-serif;
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFFFFF;
}
a:hover {
	text-decoration: none;
	color: #9966FF;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
}
#Layer23 {
	position:absolute;
	left:588px;
	top:175px;
	width:135px;
	height:30px;
	z-index:23;
	background-color: #550A89;
	visibility: hidden;
}
#Layer24 {
	position:absolute;
	left:588px;
	top:198px;
	width:135px;
	height:28px;
	z-index:24;
	background-color: #550A89;
	visibility: hidden;
}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
</head>

<body>
<div id="Layer1"><img src="image/bloom-logo.png" width="134" height="34" alt="logo" /> &nbsp;<span class="style13">Travels</span> <img src="image/wamp.jpg" alt="pl" width="204" height="49" /></div>
<div class="style11" id="Layer2"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style1"> <a href="Boom Home Page.php">Home</a></span></div>
<div class="style11" id="Layer3" onmouseover="MM_showHideLayers('Layer3','','show','Layer23','','show')" onmouseout="MM_showHideLayers('Layer3','','show','Layer23','','hide')">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style1">&nbsp;<a href="Booking.php">Bookings</a></span></div>
<div class="style4" id="Layer5">&nbsp;&nbsp;&nbsp;&nbsp;<a href="Flight Info.php">&nbsp;Flight Info </a></div>
<div class="style4" id="Layer6">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Careers.php">Careers</a></div>
<div class="style4" id="Layer7">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="About Us.php">About Us </a></div>
<div id="Layer8">&nbsp;&nbsp;&nbsp;<span class="style11">&nbsp;<a href="Login.php">Login</a> | &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="ADMINLogin.php">Admin Login</a>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;FAQs</span></div>
<div id="Layer16"> </div>
<div id="Layer17">&nbsp;<img src="image/findlowesticon.png" width="139" height="41" /></div>
<div id="Layer18">&nbsp;<img src="image/changebookingicon.png" width="152" height="34" /></div>
<div id="Layer19">&nbsp;<img src="image/twitter.png" width="35" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/facebook.png" width="32" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/linkedin2.jpg" width="32" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/blogsite.jpg" width="32" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/youtube_icon.png" width="32" height="32" /></div>
<div id="Layer20">&nbsp;
  <label> <br />
  &nbsp;&nbsp;
  <input type="text" name="textfield" />
  </label>
&nbsp;
<label>
<input type="submit" name="Submit2" value="Search" />
</label>
</div>
<div class="style15" id="Layer21"> &nbsp;
  <form id="form1" name="form1" method="post" action="">
  </form>

  <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;REGISTRATION PAGE </p>

  <p>&nbsp;</p>

  <form action="<?php echo $editFormAction; ?>" method="post" name="form2" onsubmit="MM_validateForm('Name','','R','EmailAdd','','RisEmail','Username','','R','Password','','R');return document.MM_returnValue">
    <table width="390" height="270" align="center">
      <tr valign="baseline">
        <td nowrap align="right">Name:</td>
        <td><input name="Name" type="text" value="" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Address:</td>
        <td><input type="text" name="Address" value="" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">EmailAdd:</td>
        <td><input type="text" name="EmailAdd" value="" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">ContactNo:</td>
        <td><input type="text" name="ContactNo" value="" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Username:</td>
        <td><input type="text" name="Username" value="" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Password:</td>
        <td><input type="password" name="Password" value="" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">&nbsp;</td>
        <td><input name="Register" type="submit" id="Register" value="Register"></td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="form2">
  </form>
  <p>&nbsp;</p>
</div>
<div id="Layer22">&nbsp; <span class="style4">Make Booking </span></div>
<div class="style4" id="Layer23" onmouseover="MM_showHideLayers('Layer3','','show','Layer23','','show','Layer24','','show')" onmouseout="MM_showHideLayers('Layer3','','show','Layer23','','hide','Layer24','','hide')"><a href="Make Booking.php">&nbsp;Make Booking </a></div>
<div class="style4" id="Layer24" onmouseover="MM_showHideLayers('Layer23','','show','Layer24','','show')" onmouseout="MM_showHideLayers('Layer23','','show','Layer24','','hide')"><a href="Cancel Booking.php">&nbsp;Cancel Booking </a></div>
<div align="center">
  <table width="920" border="0" cellpadding="0" cellspacing="0">
    <!--DWLayoutTable-->
    <tr>
      <td width="920" height="125" valign="top" bgcolor="#CCCCCC"><!--DWLayoutEmptyCell-->&nbsp;</td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td height="43" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
    <tr>
      <td height="783" valign="top" bgcolor="#CCCCCC"><!--DWLayoutEmptyCell-->&nbsp;</td>
    </tr>
    <tr>
      <td height="2"></td>
    </tr>
  </table>
</div>
</body>
</html>
<?php
mysql_free_result($booking);
?>
