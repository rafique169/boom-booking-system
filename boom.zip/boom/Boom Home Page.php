<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Boom Home Page</title>
<style type="text/css">
<!--
body {
	background-image: url(image/vector-background-23.jpg);
}
#Layer1 {
	position:absolute;
	left:250px;
	top:48px;
	width:422px;
	height:64px;
	z-index:1;
	background-color: #ABBFF1;
}
#Layer2 {
	position:absolute;
	left:285px;
	top:150px;
	width:135px;
	height:30px;
	z-index:2;
	background-color: #550A89;
}
#Layer3 {
	position:absolute;
	left:586px;
	top:150px;
	width:135px;
	height:30px;
	z-index:3;
	background-color: #550A89;
}
#Layer4 {
	position:absolute;
	left:522px;
	top:150px;
	width:135px;
	height:30px;
	z-index:4;
	background-color: #550A89;
}
#Layer5 {
	position:absolute;
	left:734px;
	top:150px;
	width:135px;
	height:30px;
	z-index:5;
	background-color: #550A89;
}
#Layer6 {
	position:absolute;
	left:883px;
	top:150px;
	width:135px;
	height:30px;
	z-index:6;
	background-color: #550A89;
}
#Layer7 {
	position:absolute;
	left:437px;
	top:150px;
	width:135px;
	height:30px;
	z-index:7;
	background-color: #550A89;
}
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 18px;
}
#Layer8 {
	position:absolute;
	left:769px;
	top:107px;
	width:331px;
	height:20px;
	z-index:8;
	background-color: #550A89;
}
#Layer9 {
	position:absolute;
	left:227px;
	top:244px;
	width:882px;
	height:278px;
	z-index:9;
	background-color: #000000;
}
#Layer10 {
	position:absolute;
	left:752px;
	top:221px;
	width:331px;
	height:30px;
	z-index:10;
	background-color: #550A89;
}
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 18px; color: #FFFFFF; }
#Layer11 {
	position:absolute;
	left:752px;
	top:251px;
	width:333px;
	height:259px;
	z-index:11;
}
#Layer12 {
	position:absolute;
	left:230px;
	top:546px;
	width:423px;
	height:329px;
	z-index:12;
	background-color: #000000;
}
#Layer13 {
	position:absolute;
	left:321px;
	top:591px;
	width:312px;
	height:268px;
	z-index:13;
	background-color: #000000;
}
#Layer14 {
	position:absolute;
	left:742px;
	top:548px;
	width:109px;
	height:25px;
	z-index:14;
	background-color: #000000;
}
#Layer15 {
	position:absolute;
	left:738px;
	top:545px;
	width:360px;
	height:244px;
	z-index:15;
	background-color: #000000;
}
#Layer16 {
	position:absolute;
	left:220px;
	top:983px;
	width:878px;
	height:63px;
	z-index:16;
	background-color: #460971;
}
#Layer17 {
	position:absolute;
	left:231px;
	top:992px;
	width:197px;
	height:44px;
	z-index:17;
}
#Layer18 {
	position:absolute;
	left:440px;
	top:992px;
	width:182px;
	height:44px;
	z-index:18;
}
#Layer19 {
	position:absolute;
	left:836px;
	top:998px;
	width:236px;
	height:35px;
	z-index:19;
}
.style7 {color: #FFFFFF; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style10 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 24px;
}
.style11 {color: #FFFFFF}
#Layer20 {
	position:absolute;
	left:822px;
	top:24px;
	width:284px;
	height:62px;
	z-index:20;
	background-color: #000000;
}
.style13 {
	font-size: 24px;
	color: #565A5C;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFFFFF;
}
a:hover {
	text-decoration: none;
	color: #FFFFFF;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
}
#Layer21 {
	position:absolute;
	left:586px;
	top:175px;
	width:135px;
	height:26px;
	z-index:21;
	background-color: #550A89;
	visibility: hidden;
}
#Layer22 {
	position:absolute;
	left:586px;
	top:196px;
	width:135px;
	height:24px;
	z-index:22;
	background-color: #550A89;
	visibility: hidden;
}
#Layer23 {
	position:absolute;
	left:718px;
	top:580px;
	width:371px;
	height:292px;
	z-index:23;
	background-color: #000000;
}
.style16 {
	color: #FFFFFF;
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
}
.style17 {
	color: #FFFFFF;
	font-size: 14px;
	font-family: Arial, Helvetica, sans-serif;
}
.style18 {color: #FFFFFF; font-size: 16px; font-family: Arial, Helvetica, sans-serif; }
-->
</style>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
//-->
</script>
</head>

<body>
<div id="Layer1"><img src="image/bloom-logo.png" width="134" height="34" alt="logo" /> &nbsp;<span class="style13">Travels</span>&nbsp;<img src="image/wamp.jpg" alt="pl" width="205" height="55" /></div>
<div class="style11" id="Layer2"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style1"> <a href="Boom Home Page.php">Home</a></span></div>
<div class="style11" id="Layer3" onmouseover="MM_showHideLayers('Layer3','','show','Layer21','','show')" onmouseout="MM_showHideLayers('Layer3','','show','Layer21','','hide')">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style1">&nbsp;<a href="Booking.php">Bookings</a></span></div>
<div class="style4" id="Layer5">&nbsp;<a href="Flight Info.php">&nbsp;&nbsp;&nbsp;&nbsp;Flight Info</a> </div>
<div class="style4" id="Layer6">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Careers.php">Careers</a></div>
<div class="style4" id="Layer7">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="About Us.php">About Us </a></div>
<div id="Layer8">&nbsp;&nbsp;&nbsp;<span class="style11"><a href="Login.php">&nbsp;Login</a> | &nbsp;&nbsp;&nbsp;&nbsp;<a href="ADMINLogin.php">&nbsp;Admin Login &nbsp;</a>&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;FAQs</span></div>
<div id="Layer9">
  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="880" height="280">
    <param name="movie" value="image/boom.swf" />
    <param name="quality" value="high" />
    <embed src="image/boom.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="880" height="280"></embed>
  </object>
</div>
<div class="style4" id="Layer12">
  <p> &nbsp;<span class="style10">Boom News and Events</span> </p>
  <p>&nbsp;&nbsp;&nbsp;&nbsp;<img src="image/news.jpg" width="58" height="58" /> </p>
  <p>&nbsp;&nbsp;&nbsp;&nbsp;<img src="image/twitterbirds.jpg" width="58" height="58" />&nbsp; </p>
</div>
<div id="Layer13">
  <p class="style7">&nbsp;</p>
<marquee  behavior="scroll" direction="up" scrollamount="1"> 
<p class="style16">&nbsp;&nbsp;Upcoming Events 2012</p>
<p class="style11"> April 16th - Wilbur Wright's Birthday - details coming soon </p>
<p class="style11">August 19th - Orville Wright's Birthday and National Aviation Day - events at Wright Brothers National Memorial, details coming soon  </p>
<p class="style11"> 109th Celebration of Powered Flight - Recognizing the 100th anniversary of Marine Corps Aviation
  CALENDAR OF EVENTS</p>
<p class="style18">--DECEMBER 16-17, 2012</p>
<p class="style17"> All events are open to the public, but reservations are required for the Luncheons and for the Celebration Dinner.</p>
<p class="style17"> Call 252-441-1903 to make reservations for these events.  </p>
<p class="style17">Sunday, December 16:
  Evening Celebration Social Event - Details available in November
  
  Monday, December 17: Wright Brothers National Memorial Pavilion
  8:30 AM � 9:00 AM Northeastern High School Band Concert
  9:00 AM � 10:30 AM 109th Celebration Ceremonies </p> 
</marquee>
</div>
<div id="Layer14"><span class="style4">Promotions</span></div>
<div id="Layer16"> </div>
<div id="Layer17">&nbsp;<img src="image/findlowesticon.png" width="139" height="41" /></div>
<div id="Layer18">&nbsp;<img src="image/changebookingicon.png" width="152" height="34" /></div>
<div id="Layer19">&nbsp;<img src="image/twitter.png" width="35" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/facebook.png" width="32" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/linkedin2.jpg" width="32" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/blogsite.jpg" width="32" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/youtube_icon.png" width="32" height="32" /></div>
<div id="Layer20">&nbsp;
  <label> <br />
  &nbsp;&nbsp;&nbsp;&nbsp;
  <input type="text" name="textfield" />
  </label>
&nbsp;
<label>
<input type="submit" name="Submit2" value="Search" />
</label>
</div>
<div class="style4" id="Layer21" onmouseover="MM_showHideLayers('Layer3','','show','Layer21','','show','Layer22','','show')" onmouseout="MM_showHideLayers('Layer3','','show','Layer21','','hide','Layer22','','hide')"><a href="Make Booking.php">Make Booking</a> </div>
<div class="style4" id="Layer22" onmouseover="MM_showHideLayers('Layer21','','show','Layer22','','show')" onmouseout="MM_showHideLayers('Layer21','','show','Layer22','','hide')"><a href="Cancel Booking.php">Cancel Booking</a> </div>
<div id="Layer23">
<marquee  behavior="scroll" direction="up" scrollamount="1">
<div align="justify">
  <p class="style11"> IN CONJUNCTION with Bloom Airways 100th destination launch, an array of special offers and promotions awaits lucky winners.
    
    Malaysians can now sign up for the promotion on bloomtravels.com/100 for a chance to win free tickets to over 100 destinations.    </p>
  <p class="style11">The airline has 100 pairs of Economy Class tickets to give away to lucky passengers.
    
    Bloom Airways Holidays, the airline�s holiday division, is also introducing an attractive KL stop-over package at special rates giving travellers a chance to explore the sights of Kuala Lumpur before continuing to their onward destinations.    </p>
  <p class="style11">Bloom Airways chief executive officer Akbar Al Baker said the airline�s 100th route launch was a major milestone and the promotions were a way of saying �thank you� to the travelling public.
    
    �We are preparing to mark a great milestone of reaching 100 destinations, a remarkable achievement in the short few years we have been operating.
    
    �This would not have been possible without the full support of our valued partners, be they travel agents, corporate and our leisure customers,� he said.
    
    The 100th destination promotions are available worldwide in addition to offers already promoted throughout the airline�s extensive global route network such as the two for one offer onWednesday and Thursday.
    
    In addition, the airline�s frequent flyer loyalty programme, Privilege Club is offering members bonus Qmiles and a special discount on award tickets redeemed at qmiles.com. </p>
</div>
</marquee>
</div>
<div align="center">
  <table width="920" border="0" cellpadding="0" cellspacing="0">
    <!--DWLayoutTable-->
    <tr>
      <td width="920" height="125" valign="top" bgcolor="#CCCCCC"><!--DWLayoutEmptyCell-->&nbsp;</td>
    </tr>
    <tr>
      <td height="43" valign="top" bgcolor="#CCCCCC">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
    <tr>
      <td height="886" valign="top" bgcolor="#CCCCCC"><p>&nbsp;</p>
      <p>&nbsp;</p>        <p>&nbsp;&nbsp;&nbsp;</p></td>
    </tr>
    <tr>
      <td height="2"></td>
    </tr>
  </table>
</div>
</body>
</html>