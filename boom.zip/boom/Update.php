<?php require_once('Connections/booking.php'); ?>
<?php
$currentPage = $_SERVER["PHP_SELF"];

function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE booking SET Name=%s, fromcity=%s, tocity=%s, lvndate=%s, returndate=%s, adults=%s, children=%s WHERE bokknno=%s",
                       GetSQLValueString($_POST['Name'], "text"),
                       GetSQLValueString($_POST['fromcity'], "text"),
                       GetSQLValueString($_POST['tocity'], "text"),
                       GetSQLValueString($_POST['lvndate'], "date"),
                       GetSQLValueString($_POST['returndate'], "date"),
                       GetSQLValueString($_POST['adults'], "int"),
                       GetSQLValueString($_POST['children'], "int"),
                       GetSQLValueString($_POST['bokknno'], "int"));

  mysql_select_db($database_booking, $booking);
  $Result1 = mysql_query($updateSQL, $booking) or die(mysql_error());
}

$maxRows_Recordset1 = 1;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

mysql_select_db($database_booking, $booking);
$query_Recordset1 = "SELECT * FROM booking";
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $booking) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;

$queryString_Recordset1 = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_Recordset1") == false && 
        stristr($param, "totalRows_Recordset1") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_Recordset1 = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_Recordset1 = sprintf("&totalRows_Recordset1=%d%s", $totalRows_Recordset1, $queryString_Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update</title>
<style type="text/css">
<!--
body {
	background-image: url(image/vector-background-23.jpg);
	background-color: #769EE4;
}
#Layer1 {
	position:absolute;
	left:250px;
	top:48px;
	width:422px;
	height:64px;
	z-index:1;
	background-color: #ABBFF1;
}
#Layer2 {
	position:absolute;
	left:305px;
	top:150px;
	width:135px;
	height:30px;
	z-index:2;
	background-color: #550A89;
}
#Layer3 {
	position:absolute;
	left:606px;
	top:150px;
	width:135px;
	height:30px;
	z-index:3;
	background-color: #550A89;
}
#Layer4 {
	position:absolute;
	left:522px;
	top:150px;
	width:135px;
	height:30px;
	z-index:4;
	background-color: #550A89;
}
#Layer5 {
	position:absolute;
	left:754px;
	top:150px;
	width:135px;
	height:30px;
	z-index:5;
	background-color: #550A89;
}
#Layer6 {
	position:absolute;
	left:903px;
	top:150px;
	width:135px;
	height:30px;
	z-index:6;
	background-color: #550A89;
}
#Layer7 {
	position:absolute;
	left:456px;
	top:150px;
	width:135px;
	height:30px;
	z-index:7;
	background-color: #550A89;
}
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 18px;
}
#Layer8 {
	position:absolute;
	left:769px;
	top:107px;
	width:331px;
	height:20px;
	z-index:8;
	background-color: #550A89;
}
#Layer9 {
	position:absolute;
	left:208px;
	top:220px;
	width:503px;
	height:278px;
	z-index:9;
	background-color: #000000;
}
#Layer10 {
	position:absolute;
	left:752px;
	top:221px;
	width:331px;
	height:30px;
	z-index:10;
	background-color: #550A89;
}
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 18px; color: #FFFFFF; }
#Layer11 {
	position:absolute;
	left:752px;
	top:251px;
	width:330px;
	height:295px;
	z-index:11;
}
#Layer12 {
	position:absolute;
	left:208px;
	top:553px;
	width:491px;
	height:236px;
	z-index:12;
	background-color: #000000;
}
#Layer13 {
	position:absolute;
	left:283px;
	top:678px;
	width:193px;
	height:48px;
	z-index:13;
	background-color: #000000;
}
#Layer14 {
	position:absolute;
	left:283px;
	top:594px;
	width:186px;
	height:63px;
	z-index:14;
	background-color: #000000;
}
#Layer15 {
	position:absolute;
	left:739px;
	top:570px;
	width:348px;
	height:244px;
	z-index:15;
	background-color: #000000;
}
#Layer16 {
	position:absolute;
	left:219px;
	top:927px;
	width:878px;
	height:63px;
	z-index:16;
	background-color: #460971;
}
#Layer17 {
	position:absolute;
	left:230px;
	top:936px;
	width:197px;
	height:44px;
	z-index:17;
}
#Layer18 {
	position:absolute;
	left:439px;
	top:936px;
	width:182px;
	height:44px;
	z-index:18;
}
#Layer19 {
	position:absolute;
	left:835px;
	top:942px;
	width:236px;
	height:35px;
	z-index:19;
}
.style11 {color: #FFFFFF}
#Layer20 {
	position:absolute;
	left:836px;
	top:28px;
	width:265px;
	height:59px;
	z-index:20;
	background-color: #000000;
}
.style13 {
	font-size: 24px;
	color: #565A5C;
}
#Layer21 {
	position:absolute;
	left:299px;
	top:271px;
	width:695px;
	height:48px;
	z-index:21;
	background-color: #000000;
}
#Layer22 {
	position:absolute;
	left:230px;
	top:211px;
	width:127px;
	height:31px;
	z-index:22;
	background-color: #550A89;
}
.style15 {
	font-size: 16px;
	font-family: Arial, Helvetica, sans-serif;
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFFFFF;
}
a:hover {
	text-decoration: none;
	color: #9966FF;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
}
#Layer23 {
	position:absolute;
	left:606px;
	top:172px;
	width:135px;
	height:28px;
	z-index:23;
	background-color: #550A89;
	visibility: hidden;
}
#Layer24 {
	position:absolute;
	left:606px;
	top:196px;
	width:135px;
	height:29px;
	z-index:24;
	background-color: #550A89;
	visibility: hidden;
}
#Layer25 {
	position:absolute;
	left:324px;
	top:281px;
	width:57px;
	height:24px;
	z-index:25;
}
#Layer26 {
	position:absolute;
	left:400px;
	top:281px;
	width:77px;
	height:24px;
	z-index:26;
	background-color: #550A89;
}
.style18 {color: #565A5C}
#Layer27 {
	position:absolute;
	left:246px;
	top:378px;
	width:831px;
	height:380px;
	z-index:27;
	background-color: #000000;
}
#Layer28 {
	position:absolute;
	left:492px;
	top:281px;
	width:86px;
	height:25px;
	z-index:28;
}
.style21 {color: #FF0000}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
//-->
</script>
</head>

<body>
<div id="Layer1"><img src="image/bloom-logo.png" width="134" height="34" alt="logo" />&nbsp;<span class="style13">Travel</span><span class="style18">S</span>&nbsp;<img src="image/wamp.jpg" alt="pl" width="206" height="61" /></div>
<div class="style11" id="Layer2"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Boom Home Page.php">&nbsp;<span class="style1"> Home</span></a><span class="style1"></span></div>
<div class="style11" id="Layer3" onmouseover="MM_showHideLayers('Layer3','','show','Layer23','','show')" onmouseout="MM_showHideLayers('Layer3','','show','Layer23','','hide')">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style1">&nbsp;<a href="Booking.php">Bookings</a></span></div>
<div class="style4" id="Layer5">&nbsp;&nbsp;&nbsp;&nbsp;<a href="Flight Info.php">&nbsp;Flight Info</a> </div>
<div class="style4" id="Layer6">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Careers.php">&nbsp;Careers</a></div>
<div class="style4" id="Layer7">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="About Us.php">About Us </a></div>
<div id="Layer8">&nbsp;&nbsp;<span class="style11"><a href="Boom Home Page.php">Logout</a> | &nbsp;<a href="ADMINLogin.php">Admin Login &nbsp;</a>&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;FAQs</span></div>
<div id="Layer16"> </div>
<div id="Layer17">&nbsp;<img src="image/findlowesticon.png" width="139" height="41" /></div>
<div id="Layer18">&nbsp;<img src="image/changebookingicon.png" width="152" height="34" /></div>
<div id="Layer19">&nbsp;<img src="image/twitter.png" width="35" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/facebook.png" width="32" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/linkedin2.jpg" width="32" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/blogsite.jpg" width="32" height="32" />&nbsp;&nbsp;&nbsp;<img src="image/youtube_icon.png" width="32" height="32" /></div>
<div id="Layer20">&nbsp;
  <label> <br />
  &nbsp;&nbsp;
<input type="text" name="textfield" />
  </label>
&nbsp;
<label>
<input type="submit" name="Submit2" value="Search" />
</label>
</div>
<div class="style15" id="Layer21"> &nbsp;&nbsp;</div>
<div id="Layer22">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style4">Update</span></div>
<div id="Layer23" onmouseover="MM_showHideLayers('Layer3','','show','Layer23','','show','Layer24','','show')" onmouseout="MM_showHideLayers('Layer3','','show','Layer23','','hide','Layer24','','hide')">&nbsp;&nbsp;<span class="style4">&nbsp;<a href="Make Booking.php">Make Booking</a> </span></div>
<div class="style4" id="Layer24" onmouseover="MM_showHideLayers('Layer23','','show','Layer24','','show')" onmouseout="MM_showHideLayers('Layer23','','show','Layer24','','hide')"><a href="Cancel Booking.php">&nbsp;Cancel Booking </a></div>
<div class="style4" id="Layer25"><a href="View.php">&nbsp;View</a></div>
<div class="style4" id="Layer26"> &nbsp;<a href="Update.php">Update</a> </div>
<div id="Layer27">
  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, 0, $queryString_Recordset1); ?>">First</a> &nbsp;<a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, max(0, $pageNum_Recordset1 - 1), $queryString_Recordset1); ?>">Previous</a>&nbsp;&nbsp;&nbsp;<a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, min($totalPages_Recordset1, $pageNum_Recordset1 + 1), $queryString_Recordset1); ?>">Next</a> &nbsp;&nbsp;&nbsp;<a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, $totalPages_Recordset1, $queryString_Recordset1); ?>">Last</a>
<table width="377" height="322" align="center">
      <tr valign="baseline">
        <td nowrap align="right"><span class="style11">Name:</span></td>
        <td><input type="text" name="Name" value="<?php echo $row_Recordset1['Name']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><span class="style11">Bokknno:</span></td>
        <td><span class="style21"><?php echo $row_Recordset1['bokknno']; ?></span></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><span class="style11">Fromcity:</span></td>
        <td><input type="text" name="fromcity" value="<?php echo $row_Recordset1['fromcity']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><span class="style11">Tocity:</span></td>
        <td><input type="text" name="tocity" value="<?php echo $row_Recordset1['tocity']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><span class="style11">Lvndate:</span></td>
        <td><input type="text" name="lvndate" value="<?php echo $row_Recordset1['lvndate']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><span class="style11">Returndate:</span></td>
        <td><input type="text" name="returndate" value="<?php echo $row_Recordset1['returndate']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><span class="style11">Adults:</span></td>
        <td><input type="text" name="adults" value="<?php echo $row_Recordset1['adults']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><span class="style11">Children:</span></td>
        <td><input type="text" name="children" value="<?php echo $row_Recordset1['children']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><span class="style11"></span></td>
        <td><input type="submit" value="Update record"></td>
      </tr>
    </table>
    <input type="hidden" name="MM_update" value="form1">
    <input type="hidden" name="bokknno" value="<?php echo $row_Recordset1['bokknno']; ?>">
  </form>
  <p>&nbsp;</p>
</div>
<div class="style4" id="Layer28"><a href="Delete.php">&nbsp;&nbsp;Delete</a></div>
<div align="center">
  <table width="920" border="0" cellpadding="0" cellspacing="0">
    <!--DWLayoutTable-->
    <tr>
      <td width="920" height="125" valign="top" bgcolor="#CCCCCC"><!--DWLayoutEmptyCell-->&nbsp;</td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td height="43" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
    <tr>
      <td height="821" valign="top" bgcolor="#CCCCCC"><!--DWLayoutEmptyCell-->&nbsp;</td>
    </tr>
  </table>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
