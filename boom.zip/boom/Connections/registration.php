<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_registration = "localhost";
$database_registration = "boom";
$username_registration = "root";
$password_registration = "";
$registration = mysql_pconnect($hostname_registration, $username_registration, $password_registration) or trigger_error(mysql_error(),E_USER_ERROR); 
?>