<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_booking = "localhost";
$database_booking = "boom";
$username_booking = "root";
$password_booking = "";
$booking = mysql_pconnect($hostname_booking, $username_booking, $password_booking) or trigger_error(mysql_error(),E_USER_ERROR); 
?>